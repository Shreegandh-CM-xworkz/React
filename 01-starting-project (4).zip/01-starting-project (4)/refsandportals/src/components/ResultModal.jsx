import { forwardRef, useImperativeHandle, useRef } from "react";
import { createPortal } from "react-dom";
const ResultModal = forwardRef(function ResultModal(
  { targetTime, remainingTime, onReset },
  ref
) {
  //in this case always ref will be in second parameter
  //useImperativeHandle() is ment to work with farwardRef;it is used because tommoroow if someone changes the dialog to div in that case it is helpful
  //now the idea is to detach the dialog elem from another component so we need another useRef
  const dialog = useRef();
  const userLost = remainingTime <= 0;
  const formattedRemainingTime = (remainingTime / 1000).toFixed(2);
  const score = Math.round((1 - remainingTime / (targetTime * 1000)) * 100);
  useImperativeHandle(ref, () => {
    return {
      //this object should expose the properties and methis to the other component
      open() {
        //returns a method our wish for naming
        dialog.current.showModal();
      },
    };
  });
  return createPortal(
    //is to shift the html/ jsx code  to different place in the dom to ease the acess and styling and other stuffs for our convinience
    // create portal takes 2 args 1-jsx/html,2-where this code should be rendered
    <dialog ref={dialog} className="result-modal">
      {userLost && <h2>Your lost </h2>}
      {!userLost && <h2>Your Score :{score} </h2>}
      <p>
        The target time was <strong>{targetTime} seconds.</strong>
      </p>
      <p>
        You stopped the timer whith{" "}
        <strong>{formattedRemainingTime} seconds left</strong>
      </p>
      <form method="dialog" onSubmit={onReset}>
        <button>Close</button>
      </form>
    </dialog>,
    document.getElementById("modal") //see index.html model div is written on top that is close to root.but on inspect it was in different place .
  );
});
export default ResultModal;
