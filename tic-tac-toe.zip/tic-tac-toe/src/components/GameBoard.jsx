export default function GameBoard({ onSelectsquare, board }) {
  //   const [gameBoard, setGameBoard] = useState(initialGameBoard);

  //   function handleSelectSquare(rowIndex, colIndex) {
  // //     //  prevGameBoard[rowIndex][colIndex]='X'
  //     //return prevGameBoard; --this procedure is not applied for objects and
  //     //arrays because objects and arrays deals with reference in js this happens faster before the react schedules the useState
  //     //create a deep copy ie create a new array and copy the old elements to new then change the value
  //     setGameBoard((prevGameBoard) => {
  //       const updatedBoard = [
  //         ...prevGameBoard.map((innerArray) => [...innerArray]),
  //       ];
  //       updatedBoard[rowIndex][colIndex] = activePLayerSymbol;
  //       return updatedBoard;
  //     });
  //     onSelectsquare();
  //   }
  return (
    <>
      <ol id="game-board">
        {board.map((row, rowIndex) => (
          <li key={rowIndex}>
            <ol>
              {row.map((playerSymbol, colIndex) => (
                <li key={colIndex}>
                  <button
                    onClick={() => onSelectsquare(rowIndex, colIndex)}
                    disabled={playerSymbol !== null}
                  >
                    {playerSymbol}
                  </button>
                </li>
              ))}
            </ol>
          </li>
        ))}
      </ol>
    </>
  );
}
